import os
import socket 
FILE_INFORMATION = {}

def word_count(text_file):	
	data = text_file.read()
	word_list = data.split()		
	return len(word_list)
		
def write_word_count(output):
	output.write('Printing word count for each file in data...\n')
	for text_file in FILE_INFORMATION:
		output.write(f"{text_file}: {FILE_INFORMATION[text_file]}\n")
		
def write_max_count(output):
	max_value = 0
	target_file = ""
	for count in FILE_INFORMATION.values():
		if count > max_value:
			max_value = count
	for key in FILE_INFORMATION.keys():
		if FILE_INFORMATION[key] == max_value:
			target_file = key
	output.write(f"File with maximum no. of words: {target_file}\n")
	
def write_total_count(output):
	count = 0
	for key in FILE_INFORMATION:
		count += FILE_INFORMATION[key]
	
	output.write(f"Total word count of all files in data directory: {count}\n")
	
def write_ip_address(output):
	hostname = socket.gethostname()
	ip_address = socket.gethostbyname(hostname)
	output.write(f'Machine\'s IP address: {ip_address}\n') 
	
def write_to_console():
	with open('output/result.txt', 'r') as input:
		info = input.read()
		print(info)
		

if __name__ == "__main__":
	entries = os.scandir("data/")
	for entry in entries:
		with open(f"data/{entry.name}","r") as f:
			FILE_INFORMATION[entry.name] = word_count(f)
	with open("output/result.txt", "w") as output:
		write_word_count(output)
		write_max_count(output)
		write_total_count(output)
		write_ip_address(output)
	write_to_console()
	
